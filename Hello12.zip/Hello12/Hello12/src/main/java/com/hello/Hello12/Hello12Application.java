package com.hello.Hello12;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hello12Application {

	public static void main(String[] args) {
		SpringApplication.run(Hello12Application.class, args);
	}

}
